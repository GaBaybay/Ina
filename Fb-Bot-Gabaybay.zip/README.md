 # Fb Bot

This Fb Bot was made by Earl Shine Sawir

Credits:

John Paul Caigas

Earl Shine Sawir

Do not steal without proper credits!